var runInPageContext, wrapper;

wrapper = function () {
/*globals $ */

$.getScript('https://ajax.googleapis.com/ajax/libs/angularjs/1.0.7/angular.min.js');
$.getScript('https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js');
};

runInPageContext = function (fn) {
	var script = document.createElement('script');
	script.textContent = '('+ fn +')();';
	script.classList.add('goko-salvager');
	document.body.appendChild(script);
};

runInPageContext(wrapper);
